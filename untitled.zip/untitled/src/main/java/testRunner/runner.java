package testRunner;

import util.DriverFactory;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;

@CucumberOptions(
            features={"src/test/java/features"},
            glue={"stepDefinitions", "util"},
            tags = "@Content and @Links",
            plugin=
                     {
                    "summary","pretty","html:Reports/CucumberReport/Reports.html",
                    "json:Reports/CucumberReport/Report",
                             "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"
                     }
            )
public class runner extends AbstractTestNGCucumberTests {
   static WebDriver driver = DriverFactory.getDriver();


    @BeforeSuite
    public  void  beforeSuits(){
       // System.out.println("Before Suit");
    }

    @BeforeTest()
    public  void beforeTest(){
        // System.out.println("Before Test");
    }

    @BeforeClass
    public void beforeClass(){
        //  System.out.println("Before Class");
    }

    @BeforeMethod
    public void beforeMethod(){
        //    System.out.println("Before Method");
    }
    @BeforeGroups
    public void beforeGroups(){
        //   System.out.println("Before Groups");
    }

    @AfterMethod
    public  void afterMethod(){
        //   System.out.println("After Method");
    }
    @AfterClass
    public  void afterClass(){
        //   System.out.println("After Class");
    }
    @AfterTest
    public  void afterTest(){
        //   System.out.println("After Test");

    }
    @AfterSuite
    public  void afterSuite(){
        //   System.out.println("After Suite");

    }
    @AfterGroups
    public  void afterGrups(){
        //   System.out.println("After Gruops");

    }
}
