package util;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.util.Properties;
import java.util.concurrent.TimeUnit;

public class DriverFactory {
    static WebDriver driver;
    static Properties properties;
   public static WebDriver intialize_Driver (String browser){
       properties = configReader.getProperties();
       if (browser.equals("Chrome")){
           WebDriverManager.chromedriver().setup();
           driver=new ChromeDriver();
       } else if (browser.equals("Firefox")) {
           WebDriverManager.firefoxdriver().setup();
           driver=new FirefoxDriver();
       }
       else{
           WebDriverManager.chromedriver().setup();
           driver=new ChromeDriver();
       }

       driver.get(properties.getProperty("url"));
       driver.manage().window().maximize();
       driver.manage().timeouts().pageLoadTimeout(Integer.parseInt(properties.getProperty("pageLoadTimeout")), TimeUnit.SECONDS);  ;
       driver.manage().timeouts().implicitlyWait(Integer.parseInt(properties.getProperty("implicitlyWait")), TimeUnit.SECONDS);
    return  getDriver();
    }


    public static synchronized WebDriver getDriver(){
        return  driver;
    }
}
