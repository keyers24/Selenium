package util;

import io.cucumber.java.After;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Before;
import io.cucumber.java.BeforeStep;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;

import java.util.Properties;

public class Hooks {
    WebDriver driver;
    Properties properties;
    @Before
    public  void before(){
       // System.out.println("before");
        String browser= Reporter.getCurrentTestResult().getTestContext().getCurrentXmlTest().getParameter("browser");
        properties= configReader.initinilizeProperties();
        driver=DriverFactory.intialize_Driver(browser);


    }
    @BeforeStep
    public  void beforeStep(){
       // System.out.println("beforeStep");
    }
    @After
    public  void After(){
       // System.out.println("After");
        driver.quit();
    }
    @AfterStep
    public  void AfterStep(){
       // System.out.println("AfterStep");
    }
}
