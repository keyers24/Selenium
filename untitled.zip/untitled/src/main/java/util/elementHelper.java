package util;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.util.List;

public class elementHelper {

    WebDriver driver;
    WebDriverWait wait;
    Actions action ;

    public  elementHelper(WebDriver driver){
        this.driver = driver;
        this.wait = new WebDriverWait(driver, 10); // Bekleme işlemleri
        this.action= new Actions(driver);// klavye ve mouse işlemlerinin tamamı
    }



    public WebElement findElement(By key){
        WebElement element = presenceElement(key);
        scrollToElement(element);
        return  element;
    }
    // liste şeklinde element alma
    public  List<WebElement> findElements (By key){
        List<WebElement> elements = presenceElements(key);
        scrollToElement(elements.get(0)); // ilk baştaki elementin üzerine git
        return  elements;
    }

    public   void click(By key){

               findElement(key).click();
    }

    public   void senKey(By key,String text){

            findElement(key).sendKeys(text);

    }
    //Textini getirme
    public String getText(By key)
    {
        return findElement(key).getText();
    }

    // texti doğrulama
    public boolean checkElementText(By key,String text)
    {
        return wait.until(ExpectedConditions.textToBe(key,text));
    }


    public   void checkElementVisible(By key){

        wait.until(ExpectedConditions.visibilityOf(driver.findElement(key)));


    }
    //title doğrulama
    public boolean checkTitle(String text)
    {
        return wait.until(ExpectedConditions.titleIs(text));
    }
    //element visible doğrulama
    public void checkElementTVisible(By key)
    {
         wait.until(ExpectedConditions.visibilityOf(findElement(key)));
    }

    public  String getAttiribute(By key,String Attr)
    {
        return findElement(key).getAttribute(Attr);
    }

    public  void chechAttiribute(By key,String Attr,String text)
    {
        Assert.assertEquals(getAttiribute(key,Attr),text);
    }

    //listeden istediğin elementi bul text ile karşılaştır ve tıkla
    public void clickElementWithText(By key,String text){
        boolean find=false;
        List<WebElement> elements =wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(key)); //findElements(key);
        for (WebElement element : elements)
        {
            if (element.getText().contains(text)){
                element.click();
                find=true;
                break;
            }
        }
        Assert.assertEquals(true,find);
    }
    //listeden istediğin elementi bul text ile karşılaştır
    public void checkElementWithText(By key,String text){
        boolean find=false;
        List<WebElement> elements = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(key)); //findElements(key);
        for (WebElement element : elements)
        {
            if (element.getText().contains(text)){
                find=true;
                break;
            }
        }
        Assert.assertEquals(true,find);
    }

    //listeden istediğin elementi bul karşılaştır ve text2 ile değiştir
    public void sendKeyElementWithText(By key,String text,String text2){
        boolean find=false;
        List<WebElement> elements = findElements(key);
        for (WebElement element : elements)
        {
            if (element.getText().equals(text)){
                element.sendKeys(text2);
                find=true;
                break;
            }
        }
        Assert.assertEquals(true,find);
    }



    public List<WebElement> presenceElements(By key){ //Liste yüklenene kadar
        return wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(key));
    }

    public WebElement presenceElement(By key){ // element yüklenene kadar
        return wait.until(ExpectedConditions.presenceOfElementLocated(key));
    }

    public  void scrollToElement(WebElement element){ // sayfada elementin üstüne gitme
        String scrollElementIntoMiddle= "var viewportHeight= Math.max(document.documentElement.clientHeight, window.innerHeight || 0);*"
                + "var elementTop = arguments[0].getBoundingClientRect().top;"
                + "window.scrollBy(0,elementTop-(viewPortHeight/2));";
        ((JavascriptExecutor) driver).executeScript(scrollElementIntoMiddle, element);


    }

}
