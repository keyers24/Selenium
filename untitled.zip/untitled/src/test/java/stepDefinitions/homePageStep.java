package stepDefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.homePage;
import util.DriverFactory;

public class homePageStep {

    homePage homepage= new homePage(DriverFactory.getDriver());

    @Given("omer is home page")
    public  void omer_is_home_page(){
        homepage.checkHomePage();
    }

    @Then("should see banner")
    public void shouldSeeBanner() {
        homepage.checkBanner();
    }

    @Then("should see {string} card")
    public void shouldSeeCard(String name) {
        homepage.checkCard(name);
    }

    @When("click {string} card")
    public void clickCard(String card) {
        homepage.clickCard(card);
    }


}
