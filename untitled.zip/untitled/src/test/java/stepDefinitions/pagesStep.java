package stepDefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.homePage;
import pages.pagesPage;
import util.DriverFactory;

public class pagesStep {
    pagesPage page=new pagesPage(DriverFactory.getDriver());
    homePage homepage= new homePage(DriverFactory.getDriver());
    @Then("should see {string} Page")
    public void shouldSeePage(String pageName) {

        page.checkTitle(pageName);
    }

    @Given("omer is {string} page")
    public void omerIsPage(String name) {
        homepage.checkHomePage();
        homepage.clickCard(name);
        page.checkTitle(name);
    }

    @When("click {string} menu")
    public void clickMenu(String menu) {
        page.clickMenu(menu);
    }



    @Given("omer is at {string} under {string}  page")
    public void omerIsAtUnderPage(String menu, String underMenu ) {

        homepage.checkHomePage();
        homepage.clickCard(menu);
        page.checkTitle(menu);
        page.clickMenu(underMenu);
        page.checkTitle(underMenu);
    }

    @When("pick {string} using choose file button")
    public void pickUsingChooseFileButton(String file) {
        page.chooseFile(file);
    }

    @Then("should see {string} file path")
    public void shouldSeeFilePath(String file) {
        page.checkFileText(file);
    }

    @When("click {string} following button")
    public void clickFollowingButton(String link) {
        page.clickLinks(link);
    }

    @Then("should see {string} response code")
    public void shouldSeeResponseCode(String code) {
        page.checkResponseCode(code);
    }
}
