package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import util.elementHelper;

public class pagesPage {

    By title=By.cssSelector(".main-header");
    By menuElement=By.cssSelector(".show .btn-light span");
    By chooseFile = By.id("uploadFile");
    By fileText=By.id("uploadedFilePath");
    By LinkText=By.cssSelector("#linkWrapper a");
    By reponseCode= By.cssSelector("#linkResponse b:nth-child(1)");
    WebDriver driver;
    WebDriverWait wait;
    elementHelper helper;
    public pagesPage(WebDriver driver) {
        this.driver=driver;
        this.wait=new WebDriverWait(driver,10);
        this.helper=new elementHelper(driver);
    }

    public  void checkTitle(String name){
        helper.checkElementText(title,name);
        //wait.until(ExpectedConditions.textToBe(title,name));
    }

    public  void clickMenu(String menu){
        helper.clickElementWithText(menuElement,menu);
    }
    public  void chooseFile(String file){
      //helper.findElement(chooseFile).sendKeys(file);
        helper.senKey(chooseFile,file);
    }
    public  void checkFileText(String file){
    // wait.until(ExpectedConditions.textToBe(fileText,file));
       helper.checkElementText(fileText,file);
    }
    public  void clickLinks(String link){
       helper.clickElementWithText(LinkText,link);
       /* boolean deger=false;
        List<WebElement> links= wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(LinkText));
        for (WebElement i :links)
        {
            if (i.getText().contains(link)){
                i.click();
                deger=true;
                break;
            }
        }
        Assert.assertEquals(true,deger);*/
    }

    public  void checkResponseCode(String code)
    {
        helper.checkElementText(reponseCode,code);
        // wait.until(ExpectedConditions.textToBe(reponseCode,code));
    }

}
