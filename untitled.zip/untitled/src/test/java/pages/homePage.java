package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import util.elementHelper;

public class homePage {
    By banner= By.cssSelector(".home-banner");
    By card = By.cssSelector(".card.mt-4.top-card h5");

    WebDriver driver;
    WebDriverWait wait;
    elementHelper helper;
    public homePage(WebDriver driver) {
        this.driver=driver;
        this.wait = new WebDriverWait(driver,10);
        this.helper=new elementHelper(driver);
    }
    public  void checkHomePage(){

        helper.presenceElement(banner);

    }

    public  void checkBanner(){
        helper.presenceElement(banner);
    }

    public  void checkCard(String name){
      helper.checkElementWithText(card,name);
       /*boolean sonuc= false;
        List<WebElement> elements = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(card));
        for (WebElement element :elements) {
            String elementText=element.getText();
            if (elementText.contains(name))
            {
                sonuc=true;
                break;
            }
        }
        Assert.assertEquals(true,sonuc); // iki değer birbirine eşitse devam değilse patlat
*/
    }

    public void clickCard(String name)
    {

        helper.clickElementWithText(card,name);
        /*boolean sonuc= false;
        List<WebElement> elements = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(card));
        for (WebElement element :elements) {
            String elementText=element.getText();
            if (elementText.contains(name))
            {
                element.click();
                sonuc=true;
                break;
            }
        }
        Assert.assertEquals(true,sonuc); // iki değer birbirine eşitse devam değilse patlat

        */
    }
}
